﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceGame
{
    class Programs
    {
        static void Main(string[] args) 
        {

            Game myGame = new Game();
            myGame.Start();
        
        }





    }
}
