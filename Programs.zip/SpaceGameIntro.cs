﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Text;

namespace SpaceGame
{
    class Game
    {

        public void Start()
        {
            //Title = "Space Game!";
            RunMainMenu();

        }

        private void RunMainMenu() 
        {
            string prompt = @"                                                                               
                                                                                
                                      ((##*                                     
                        ..          ((((((##            .                    .  
                                   ((((((((###    .                             
               *                             ...                                
                                              ...                               
                                               ...                              
                                    (,(((((((   ...                             
                                  #/*,  ,,**,((  ...                            
         .  .   .                (#*,,********#(  ..             . .            *
                                 ((********,**(*  ...                           
                                  ((#*******#(,   ...                           
                           (         ((((#(/.     ...(                          
                          ##                      ...##                         
                         ##(           ((#        ...(##                        *
                        ##/(.         .((#          (((/#                       
                *       #////..       ,((#      ..  /(((/                       
                       ##((((         .((#       ..,((((##                      
                       ##(((((         ((#      ...(((((##                      
                       ##((((((        ((#     ...((((((##                      
                        #(((((( #((((((((#((((((, ((((((#                       
                  .     .#((     *,... (#, ...**     ((#           .            
            .                    *,,   . . ...,*                                
                                **...       ...*,                               
                                **...      ....*,                               
                                 **....   ....**                                
                                  **,.......,**                                 
                                   ***,...,***   .         *                 .   
                                     ,******                               .    
                                        ,                                       
                                                                                

                  _____                         _____                      
                 / ____|                       / ____|                     
                | (___  _ __   __ _  ___ ___  | |  __  __ _ _ __ ___   ___ 
                 \___ \| '_ \ / _` |/ __/ _ \ | | |_ |/ _` | '_ ` _ \ / _ \
                   __) | |_) | (_| | (_|  __/ | |__| | (_| | | | | | |  __/
                |_____/| .__/ \__,_|\___\___|  \_____|\__,_|_| |_| |_|\___|
                       | |                                                 
                       |_|                                                 


Welcome to the Space Game!";
            string[] options = { "Play", "About", "Exit" };
            Menu mainMenu = new Menu(prompt, options);
            int selectedIndex = mainMenu.Run();

            switch (selectedIndex)
            {
                case 0:
                    RunFirstChoice();
                    break;
                case 1:
                    DisplayAboutInfo();
                    break;
                case 2:
                    ExitGame();
                    break;
                
                   
            
            }


        }

        private void ExitGame() 
        {

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey(true);
            Environment.Exit(0);
        
        }
        private void DisplayAboutInfo() 
        {
            //Clear();
            Console.WriteLine("This game was created by Jorge Sanchez, Bryan Landaverde, Jasmine Meade and Milton Silver");
            Console.WriteLine("Game Title from http://patorjk.com/software/taag/#p=testall&f=Bloody&t=Space%20Game.");
            Console.WriteLine("Press any key to return to the menu.");
            Console.ReadKey(true);
            RunMainMenu();
        
        }

        private void RunFirstChoice() 
        {

            Console.WriteLine("Placeholder for 1st choice!");
            ExitGame();
        
        }




    }
    
}
