# SpaceGame
You and your pair programming teammate have been hired by a firm to provide a console-based prototype of a space game. Based on product owner requirements, spend the next few days implementing a space game where you travel from planet to planet (not less than 5 planets) buying and selling goods.
 
Requirements: a class library project that will be consumed by the console app project and a test project
Deliverables:
1.	An algorithm,
2.	IPO chart (Input, Process, Output), 
3.	Mockup depicting the output to the screen
4.	and a flowchart depicting the flow of the program,
5.	classes with method stubs and properties via a class diagram,
6.	use cases or test method stubs ,
7.	a list of assignments per team member with dates to be completed by
